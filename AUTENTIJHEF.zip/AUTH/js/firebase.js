  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyDkePsDe5f8DySQh5qDjWRYrqp2wEoxga4",
    authDomain: "prototipo-de-page.firebaseapp.com",
    projectId: "prototipo-de-page",
    storageBucket: "prototipo-de-page.appspot.com",
    messagingSenderId: "864063983491",
    appId: "1:864063983491:web:a0ebb6ef5a0deceaf570b6"
  };

  // Initialize Firebase
 export const app = initializeApp(firebaseConfig);
